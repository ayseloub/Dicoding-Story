// src/main.js

import router from './scripts/routes/routes.js';

document.addEventListener('DOMContentLoaded', () => {
  const skipBtn = document.getElementById('skip-btn');
  const mainContent = document.getElementById('main-content');

  if (skipBtn && mainContent) {
    skipBtn.addEventListener('click', (e) => {
      e.preventDefault();
      mainContent.focus({ preventScroll: false });
    });
  }
});

window.addEventListener('hashchange', () => {
  if (document.startViewTransition) {
    document.startViewTransition(router);
  } else {
    router();
  }
});
window.addEventListener('load', router);


