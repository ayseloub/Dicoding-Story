const HomeModel = {
  async fetchStories(token) {
    const response = await fetch('https://story-api.dicoding.dev/v1/stories?location=1', {
      headers: { Authorization: `Bearer ${token}` },
    });

    const json = await response.json();
    return json.listStory;
  }
};

export default HomeModel;
