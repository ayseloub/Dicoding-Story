import HomeModel from '../models/HomeModel.js';
import { showLoadingIndicator } from '../presenter/loading.js';

export default class HomePresenter {
  constructor() {
    this.storyListEl = document.getElementById('story-list');
  }

  async init() {
    const token = localStorage.getItem('authToken');
    const removeLoading = showLoadingIndicator();
    try {
      const stories = await HomeModel.fetchStories(token);
      this.renderStories(stories);
    } catch (error) {
      this.storyListEl.innerHTML = '<li>Gagal memuat cerita.</li>';
    } finally {
      removeLoading();
    }
  }

  renderStories(stories) {
  this.storyListEl.innerHTML = '';
  stories.forEach(story => {
    const li = document.createElement('li');
    li.innerHTML = `
      <strong>${story.name}</strong>: ${story.description}<br/>
      <img src="${story.photoUrl}" alt="story image" width="200"/><br/>
      <small>
        Latitude: ${story.lat ?? 'N/A'}, Longitude: ${story.lon ?? 'N/A'}<br/>
        Created At: ${new Date(story.createdAt).toLocaleString()}
      </small>
    `;
    this.storyListEl.appendChild(li);
  });
    }
}
