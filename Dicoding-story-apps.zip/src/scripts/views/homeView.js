import HomePresenter from '../presenter/HomePresenter.js';

const HomeView = {
  render(container) {
    container.innerHTML = `
      <h2>Daftar Cerita</h2>
      <ul id="story-list"></ul>
    `;

    const presenter = new HomePresenter();
    presenter.init();
  }
};

export default HomeView;
